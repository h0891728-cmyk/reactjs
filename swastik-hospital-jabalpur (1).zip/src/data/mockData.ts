export const DEPARTMENTS = [
  {
    id: "cardiology",
    title: "Cardiology",
    description: "Expert care for your heart, including diagnostics, treatment, and rehabilitation.",
    icon: "HeartPulse",
  },
  {
    id: "orthopedics",
    title: "Orthopedics",
    description: "Specialized treatment for bone, joint, and muscle conditions.",
    icon: "Bone",
  },
  {
    id: "neurology",
    title: "Neurology",
    description: "Advanced care for brain, spinal cord, and nervous system disorders.",
    icon: "Brain",
  },
  {
    id: "pediatrics",
    title: "Pediatrics",
    description: "Compassionate healthcare for infants, children, and adolescents.",
    icon: "Baby",
  },
  {
    id: "emergency",
    title: "Emergency Care",
    description: "24/7 emergency services with a dedicated trauma team.",
    icon: "Ambulance",
  },
  {
    id: "pharmacy",
    title: "Pharmacy",
    description: "Fully stocked pharmacy with expert pharmacists to guide you.",
    icon: "Pill",
  },
];

export const DOCTORS = [
  {
    id: 1,
    name: "Dr. Rajesh Sharma",
    speciality: "Senior Cardiologist",
    experience: "15+ Years",
    contact: "+91 98765 43210",
    image: "https://picsum.photos/seed/doc1/400/500",
  },
  {
    id: 2,
    name: "Dr. Anjali Verma",
    speciality: "Orthopedic Surgeon",
    experience: "12+ Years",
    contact: "+91 98765 43211",
    image: "https://picsum.photos/seed/doc2/400/500",
  },
  {
    id: 3,
    name: "Dr. Vikram Singh",
    speciality: "Neurologist",
    experience: "10+ Years",
    contact: "+91 98765 43212",
    image: "https://picsum.photos/seed/doc3/400/500",
  },
  {
    id: 4,
    name: "Dr. Meera Iyer",
    speciality: "Pediatrician",
    experience: "8+ Years",
    contact: "+91 98765 43213",
    image: "https://picsum.photos/seed/doc4/400/500",
  },
];

export const MEDICINES = [
  { id: 1, name: "Paracetamol", category: "Pain Relief", price: "₹20", description: "Used to treat pain and fever." },
  { id: 2, name: "Amoxicillin", category: "Antibiotics", price: "₹150", description: "Used to treat bacterial infections." },
  { id: 3, name: "Cetirizine", category: "Allergy", price: "₹45", description: "Relieves allergy symptoms." },
  { id: 4, name: "Metformin", category: "Diabetes", price: "₹80", description: "Helps control blood sugar levels." },
  { id: 5, name: "Atorvastatin", category: "Cholesterol", price: "₹120", description: "Lowers 'bad' cholesterol." },
  { id: 6, name: "Omeprazole", category: "Digestive", price: "₹60", description: "Treats heartburn and acid reflux." },
  { id: 7, name: "Amlodipine", category: "Blood Pressure", price: "₹90", description: "Treats high blood pressure." },
  { id: 8, name: "Ibuprofen", category: "Pain Relief", price: "₹35", description: "Reduces inflammation and pain." },
];

export const TESTIMONIALS = [
  {
    id: 1,
    name: "Suresh Gupta",
    text: "The care I received at Swastik Hospital was exceptional. The doctors are very professional and caring.",
    rating: 5,
  },
  {
    id: 2,
    name: "Priya Patel",
    text: "Very clean facility and the staff is extremely helpful. Highly recommended for pediatric care.",
    rating: 5,
  },
  {
    id: 3,
    name: "Amit Mishra",
    text: "The emergency department responded so quickly. I am grateful for their timely intervention.",
    rating: 4,
  },
];
