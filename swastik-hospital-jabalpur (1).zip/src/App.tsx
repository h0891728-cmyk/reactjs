import { motion } from "motion/react";
import { HeartPulse, Bone, Brain, Baby, Ambulance, Pill, Phone, MapPin, Calendar, Clock, Star, Search, Menu, X, ChevronRight, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { cn } from "./lib/utils";
import { DEPARTMENTS, DOCTORS, MEDICINES, TESTIMONIALS } from "./data/mockData";

// --- Types & Schemas ---

const appointmentSchema = z.z.object({
  name: z.z.string().min(2, "Name must be at least 2 characters"),
  email: z.z.string().email("Invalid email address"),
  phone: z.z.string().min(10, "Phone number must be at least 10 digits"),
  department: z.z.string().min(1, "Please select a department"),
  date: z.z.string().min(1, "Please select a date"),
  message: z.z.string().optional(),
});

type AppointmentFormValues = z.z.infer<typeof appointmentSchema>;

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", href: "#home" },
    { name: "About", href: "#about" },
    { name: "Services", href: "#services" },
    { name: "Doctors", href: "#doctors" },
    { name: "Pharmacy", href: "#pharmacy" },
    { name: "Contact", href: "#contact" },
  ];

  return (
    <nav className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 py-4",
      isScrolled ? "bg-white/90 backdrop-blur-md shadow-sm py-3" : "bg-transparent"
    )}>
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">
            S
          </div>
          <span className={cn("text-xl font-bold tracking-tight", isScrolled ? "text-slate-900" : "text-white")}>
            Swastik Hospital
          </span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className={cn(
                "text-sm font-medium transition-colors hover:text-emerald-600",
                isScrolled ? "text-slate-600" : "text-white/90"
              )}
            >
              {link.name}
            </a>
          ))}
          <a
            href="#appointment"
            className="bg-emerald-600 text-white px-5 py-2.5 rounded-full text-sm font-semibold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20"
          >
            Book Appointment
          </a>
        </div>

        {/* Mobile Menu Toggle */}
        <button
          className="md:hidden text-slate-900"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X className={isScrolled ? "text-slate-900" : "text-white"} /> : <Menu className={isScrolled ? "text-slate-900" : "text-white"} />}
        </button>
      </div>

      {/* Mobile Nav */}
      {isMobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-full left-0 right-0 bg-white shadow-xl p-6 flex flex-col gap-4 md:hidden"
        >
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={() => setIsMobileMenuOpen(false)}
              className="text-slate-600 font-medium hover:text-emerald-600"
            >
              {link.name}
            </a>
          ))}
          <a
            href="#appointment"
            onClick={() => setIsMobileMenuOpen(false)}
            className="bg-emerald-600 text-white text-center py-3 rounded-xl font-semibold"
          >
            Book Appointment
          </a>
        </motion.div>
      )}
    </nav>
  );
};

const Hero = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://picsum.photos/seed/hospital/1920/1080?blur=2"
          alt="Hospital Background"
          className="w-full h-full object-cover brightness-[0.4]"
          referrerPolicy="no-referrer"
        />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block px-4 py-1.5 bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 rounded-full text-xs font-bold uppercase tracking-widest mb-6">
              Welcome to Swastik Hospital
            </span>
            <h1 className="text-5xl md:text-7xl font-bold text-white leading-[1.1] mb-6">
              Advanced Healthcare <br />
              <span className="text-emerald-400">With a Human Touch</span>
            </h1>
            <p className="text-lg text-white/70 mb-10 max-w-xl leading-relaxed">
              Providing world-class medical services in Jabalpur. Our team of expert doctors and state-of-the-art technology ensure you receive the best care possible.
            </p>

            <div className="flex flex-wrap gap-4">
              <a
                href="#appointment"
                className="bg-emerald-600 text-white px-8 py-4 rounded-full font-bold hover:bg-emerald-700 transition-all flex items-center gap-2 group"
              >
                <Calendar className="w-5 h-5" />
                Book Appointment
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>
              <a
                href="tel:+919876543210"
                className="bg-white/10 backdrop-blur-md border border-white/20 text-white px-8 py-4 rounded-full font-bold hover:bg-white/20 transition-all flex items-center gap-2"
              >
                <Phone className="w-5 h-5" />
                Call Emergency
              </a>
            </div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 border-t border-white/10 pt-10"
          >
            {[
              { label: "Expert Doctors", value: "50+" },
              { label: "Modern Beds", value: "200+" },
              { label: "Happy Patients", value: "10k+" },
              { label: "Years Experience", value: "25+" },
            ].map((stat) => (
              <div key={stat.label}>
                <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-sm text-white/50 uppercase tracking-wider">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const About = () => {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-2xl">
              <img
                src="https://picsum.photos/seed/about/800/1000"
                alt="Hospital Building"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-10 -right-10 bg-emerald-600 p-8 rounded-3xl text-white shadow-xl hidden lg:block max-w-[280px]">
              <div className="text-4xl font-bold mb-2">25+</div>
              <div className="text-sm opacity-80 font-medium">Years of excellence in providing quality healthcare to the people of Jabalpur.</div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <span className="text-emerald-600 font-bold uppercase tracking-widest text-sm mb-4 block">About Us</span>
            <h2 className="text-4xl font-bold text-slate-900 mb-6 leading-tight">
              Dedicated to Your Health and Well-being
            </h2>
            <p className="text-slate-600 text-lg mb-8 leading-relaxed">
              Swastik Hospital Jabalpur has been a beacon of hope and healing for over two decades. We believe that healthcare should be accessible, affordable, and most importantly, compassionate.
            </p>

            <div className="space-y-6">
              {[
                { title: "Our Mission", text: "To provide high-quality, cost-effective medical care with a focus on patient safety and satisfaction." },
                { title: "Our Vision", text: "To be the most trusted healthcare provider in Central India, known for clinical excellence and ethical practices." },
                { title: "Our Values", text: "Integrity, Compassion, Innovation, and Excellence in everything we do." },
              ].map((item) => (
                <div key={item.title} className="flex gap-4">
                  <div className="mt-1 w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0">
                    <div className="w-2 h-2 rounded-full bg-emerald-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 mb-1">{item.title}</h4>
                    <p className="text-slate-600">{item.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const Services = () => {
  const iconMap: Record<string, any> = {
    HeartPulse, Bone, Brain, Baby, Ambulance, Pill
  };

  return (
    <section id="services" className="py-24 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-emerald-600 font-bold uppercase tracking-widest text-sm mb-4 block">Our Services</span>
          <h2 className="text-4xl font-bold text-slate-900 mb-4">Specialized Departments</h2>
          <p className="text-slate-600">We offer a wide range of medical services across various specialties, all under one roof.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {DEPARTMENTS.map((dept, index) => {
            const Icon = iconMap[dept.icon];
            return (
              <motion.div
                key={dept.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white p-8 rounded-3xl border border-slate-100 hover:border-emerald-200 hover:shadow-xl hover:shadow-emerald-600/5 transition-all group"
              >
                <div className="w-14 h-14 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600 mb-6 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                  <Icon className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{dept.title}</h3>
                <p className="text-slate-600 leading-relaxed mb-6">
                  {dept.description}
                </p>
                <a href="#" className="text-emerald-600 font-semibold flex items-center gap-2 hover:gap-3 transition-all">
                  Learn More <ChevronRight className="w-4 h-4" />
                </a>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

const Doctors = () => {
  return (
    <section id="doctors" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-2xl">
            <span className="text-emerald-600 font-bold uppercase tracking-widest text-sm mb-4 block">Our Team</span>
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Meet Our Expert Doctors</h2>
            <p className="text-slate-600">Our doctors are highly qualified professionals with years of experience in their respective fields.</p>
          </div>
          <a href="#" className="bg-slate-900 text-white px-8 py-4 rounded-full font-bold hover:bg-slate-800 transition-all">
            View All Doctors
          </a>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {DOCTORS.map((doc, index) => (
            <motion.div
              key={doc.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group"
            >
              <div className="relative aspect-[4/5] rounded-3xl overflow-hidden mb-6">
                <img
                  src={doc.image}
                  alt={doc.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-6">
                  <div className="flex gap-3">
                    <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white hover:bg-emerald-600 transition-colors cursor-pointer">
                      <Phone className="w-4 h-4" />
                    </div>
                  </div>
                </div>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-1">{doc.name}</h3>
              <p className="text-emerald-600 font-medium text-sm mb-2">{doc.speciality}</p>
              <div className="flex items-center gap-4 text-slate-500 text-sm">
                <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {doc.experience}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Pharmacy = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  const categories = ["All", ...Array.from(new Set(MEDICINES.map(m => m.category)))];

  const filteredMedicines = MEDICINES.filter(m => {
    const matchesSearch = m.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === "All" || m.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <section id="pharmacy" className="py-24 bg-emerald-900 text-white overflow-hidden relative">
      <div className="absolute top-0 right-0 w-1/3 h-full bg-emerald-800/20 skew-x-12 translate-x-1/2" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-3 gap-16">
          <div className="lg:col-span-1">
            <span className="text-emerald-400 font-bold uppercase tracking-widest text-sm mb-4 block">Pharmacy</span>
            <h2 className="text-4xl font-bold mb-6">Online Pharmacy & Medications</h2>
            <p className="text-emerald-100/70 mb-10 leading-relaxed">
              Browse our extensive list of medications. We maintain a high standard of quality and ensure all medicines are stored correctly.
            </p>

            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search medicines..."
                  className="w-full bg-white/10 border border-white/20 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <div className="flex flex-wrap gap-2">
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={cn(
                      "px-4 py-2 rounded-full text-sm font-medium transition-all",
                      activeCategory === cat ? "bg-emerald-500 text-white" : "bg-white/5 text-emerald-200 hover:bg-white/10"
                    )}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="grid sm:grid-cols-2 gap-4 max-h-[600px] overflow-y-auto pr-4 custom-scrollbar">
              {filteredMedicines.map((med) => (
                <motion.div
                  layout
                  key={med.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-3xl hover:bg-white/10 transition-all"
                >
                  <div className="flex justify-between items-start mb-4">
                    <div className="w-10 h-10 bg-emerald-500/20 rounded-xl flex items-center justify-center text-emerald-400">
                      <Pill className="w-5 h-5" />
                    </div>
                    <span className="text-emerald-400 font-bold">{med.price}</span>
                  </div>
                  <h4 className="text-lg font-bold mb-1">{med.name}</h4>
                  <p className="text-xs text-emerald-400 uppercase tracking-widest font-bold mb-3">{med.category}</p>
                  <p className="text-sm text-emerald-100/60">{med.description}</p>
                </motion.div>
              ))}
              {filteredMedicines.length === 0 && (
                <div className="col-span-full py-20 text-center text-emerald-100/40">
                  No medicines found matching your criteria.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const AppointmentForm = () => {
  const { register, handleSubmit, formState: { errors }, reset } = useForm<AppointmentFormValues>({
    resolver: zodResolver(appointmentSchema),
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const onSubmit = (data: AppointmentFormValues) => {
    console.log("Form Data:", data);
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      reset();
    }, 5000);
  };

  return (
    <section id="appointment" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-5xl mx-auto bg-slate-50 rounded-[40px] overflow-hidden shadow-2xl shadow-slate-200/50 flex flex-col md:flex-row">
          <div className="md:w-2/5 bg-emerald-600 p-12 text-white flex flex-col justify-between">
            <div>
              <h2 className="text-3xl font-bold mb-6">Book an Appointment</h2>
              <p className="text-emerald-50/80 mb-10">
                Fill out the form and our team will get back to you within 24 hours to confirm your slot.
              </p>

              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs opacity-60 uppercase font-bold tracking-wider">Call Us</div>
                    <div className="font-bold">+91 98765 43210</div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs opacity-60 uppercase font-bold tracking-wider">Working Hours</div>
                    <div className="font-bold">24/7 Emergency Services</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-12 pt-12 border-t border-white/10">
              <div className="text-sm italic opacity-80">
                "Your health is our priority. We are committed to providing you with the best medical care."
              </div>
            </div>
          </div>

          <div className="md:w-3/5 p-12">
            {isSubmitted ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="h-full flex flex-col items-center justify-center text-center"
              >
                <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 mb-6">
                  <HeartPulse className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-2">Request Received!</h3>
                <p className="text-slate-600">We've received your appointment request. Our coordinator will contact you shortly.</p>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Full Name</label>
                    <input
                      {...register("name")}
                      className={cn(
                        "w-full bg-white border rounded-2xl p-4 focus:outline-none focus:ring-2 transition-all",
                        errors.name ? "border-red-500 focus:ring-red-200" : "border-slate-200 focus:ring-emerald-100"
                      )}
                      placeholder="John Doe"
                    />
                    {errors.name && <p className="text-xs text-red-500 font-medium">{errors.name.message}</p>}
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Email Address</label>
                    <input
                      {...register("email")}
                      className={cn(
                        "w-full bg-white border rounded-2xl p-4 focus:outline-none focus:ring-2 transition-all",
                        errors.email ? "border-red-500 focus:ring-red-200" : "border-slate-200 focus:ring-emerald-100"
                      )}
                      placeholder="john@example.com"
                    />
                    {errors.email && <p className="text-xs text-red-500 font-medium">{errors.email.message}</p>}
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Phone Number</label>
                    <input
                      {...register("phone")}
                      className={cn(
                        "w-full bg-white border rounded-2xl p-4 focus:outline-none focus:ring-2 transition-all",
                        errors.phone ? "border-red-500 focus:ring-red-200" : "border-slate-200 focus:ring-emerald-100"
                      )}
                      placeholder="+91 98765 43210"
                    />
                    {errors.phone && <p className="text-xs text-red-500 font-medium">{errors.phone.message}</p>}
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Department</label>
                    <select
                      {...register("department")}
                      className={cn(
                        "w-full bg-white border rounded-2xl p-4 focus:outline-none focus:ring-2 transition-all appearance-none",
                        errors.department ? "border-red-500 focus:ring-red-200" : "border-slate-200 focus:ring-emerald-100"
                      )}
                    >
                      <option value="">Select Department</option>
                      {DEPARTMENTS.map(d => <option key={d.id} value={d.id}>{d.title}</option>)}
                    </select>
                    {errors.department && <p className="text-xs text-red-500 font-medium">{errors.department.message}</p>}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Preferred Date</label>
                  <input
                    type="date"
                    {...register("date")}
                    className={cn(
                      "w-full bg-white border rounded-2xl p-4 focus:outline-none focus:ring-2 transition-all",
                      errors.date ? "border-red-500 focus:ring-red-200" : "border-slate-200 focus:ring-emerald-100"
                    )}
                  />
                  {errors.date && <p className="text-xs text-red-500 font-medium">{errors.date.message}</p>}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Message (Optional)</label>
                  <textarea
                    {...register("message")}
                    rows={4}
                    className="w-full bg-white border border-slate-200 rounded-2xl p-4 focus:outline-none focus:ring-2 focus:ring-emerald-100 transition-all"
                    placeholder="Tell us about your symptoms..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20"
                >
                  Confirm Appointment
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

const Testimonials = () => {
  return (
    <section className="py-24 bg-slate-50 overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-emerald-600 font-bold uppercase tracking-widest text-sm mb-4 block">Testimonials</span>
          <h2 className="text-4xl font-bold text-slate-900 mb-4">What Our Patients Say</h2>
          <p className="text-slate-600">Real stories from real patients who have experienced our care.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((t, index) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white p-10 rounded-[32px] shadow-sm border border-slate-100 relative"
            >
              <div className="flex gap-1 mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className={cn("w-4 h-4", i < t.rating ? "text-yellow-400 fill-yellow-400" : "text-slate-200")} />
                ))}
              </div>
              <p className="text-slate-600 italic mb-8 leading-relaxed">"{t.text}"</p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 font-bold">
                  {t.name[0]}
                </div>
                <div>
                  <div className="font-bold text-slate-900">{t.name}</div>
                  <div className="text-xs text-slate-400 uppercase tracking-widest font-bold">Patient</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Contact = () => {
  return (
    <section id="contact" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16">
          <div>
            <span className="text-emerald-600 font-bold uppercase tracking-widest text-sm mb-4 block">Contact Us</span>
            <h2 className="text-4xl font-bold text-slate-900 mb-8">Get in Touch With Us</h2>

            <div className="space-y-8">
              <div className="flex gap-6">
                <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center text-emerald-600 flex-shrink-0">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-1 text-lg">Our Location</h4>
                  <p className="text-slate-600">123 Health Avenue, Civil Lines, Jabalpur, MP 482001</p>
                </div>
              </div>

              <div className="flex gap-6">
                <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center text-emerald-600 flex-shrink-0">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-1 text-lg">Phone Number</h4>
                  <p className="text-slate-600">+91 98765 43210 (General)</p>
                  <p className="text-slate-600">+91 98765 43211 (Emergency)</p>
                </div>
              </div>

              <div className="flex gap-6">
                <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center text-emerald-600 flex-shrink-0">
                  <Clock className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-1 text-lg">Working Hours</h4>
                  <p className="text-slate-600">OPD: 9:00 AM - 8:00 PM</p>
                  <p className="text-slate-600">Emergency: 24/7 Available</p>
                </div>
              </div>
            </div>

            <div className="mt-12 flex gap-4">
              {[Facebook, Twitter, Instagram, Linkedin].map((Icon, i) => (
                <a key={i} href="#" className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 hover:bg-emerald-600 hover:text-white transition-all">
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          <div className="rounded-[40px] overflow-hidden border-8 border-slate-50 shadow-2xl h-[500px]">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d58682.04655656113!2d79.90448152167969!3d23.183756200000003!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3981ae1a0247e205%3A0x1ed6928883f6ce!2sJabalpur%2C%20Madhya%20Pradesh!5e0!3m2!1sen!2sin!4v1708780000000!5m2!1sen!2sin"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-slate-900 text-white pt-20 pb-10">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">
                S
              </div>
              <span className="text-xl font-bold tracking-tight">Swastik Hospital</span>
            </div>
            <p className="text-slate-400 leading-relaxed mb-8">
              Leading healthcare provider in Jabalpur, committed to excellence and compassionate care.
            </p>
          </div>

          <div>
            <h4 className="font-bold mb-6 text-lg">Quick Links</h4>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#home" className="hover:text-emerald-400 transition-colors">Home</a></li>
              <li><a href="#about" className="hover:text-emerald-400 transition-colors">About Us</a></li>
              <li><a href="#services" className="hover:text-emerald-400 transition-colors">Services</a></li>
              <li><a href="#doctors" className="hover:text-emerald-400 transition-colors">Our Doctors</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6 text-lg">Departments</h4>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Cardiology</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Orthopedics</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Neurology</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Pediatrics</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6 text-lg">Newsletter</h4>
            <p className="text-slate-400 mb-6">Subscribe to get the latest health tips and news.</p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="Your email"
                className="bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 w-full"
              />
              <button className="bg-emerald-600 px-4 py-3 rounded-xl hover:bg-emerald-700 transition-all">
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-sm text-slate-500">
          <p>© 2024 Swastik Hospital Jabalpur. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

// --- Main App ---

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50 font-sans selection:bg-emerald-100 selection:text-emerald-900">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Services />
        <Doctors />
        <Pharmacy />
        <AppointmentForm />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
